from setuptools import setup

setup(name='binomial-distributions-mle',
      version='0.1',
      description='Binomial distributions',
      packages=['binomial-distributions-mle'],
      zip_safe=False)
